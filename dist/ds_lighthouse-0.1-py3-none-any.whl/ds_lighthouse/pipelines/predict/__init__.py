"""
This is a boilerplate pipeline 'predict'
generated using Kedro 0.18.1
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]

__version__ = "0.1"
